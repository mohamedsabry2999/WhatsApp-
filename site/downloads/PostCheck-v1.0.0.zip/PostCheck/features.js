// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "post",
  "name": "PostCheck",
  "nameHtml": "Post<span>Check</span>",
  "tagline": "راجع الكابشن قبل ما تنشر",
  "tools": [
    "post"
  ],
  "home": "post",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
