// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "resizer",
  "name": "SocialSizer",
  "nameHtml": "Social<span>Sizer</span>",
  "tagline": "صورة واحدة ← كل مقاسات السوشيال",
  "tools": [
    "resizer"
  ],
  "home": "resizer",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
