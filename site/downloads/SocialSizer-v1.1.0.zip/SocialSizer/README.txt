SocialSizer v1.1.0
صورة واحدة ← كل مقاسات السوشيال
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (SocialSizer)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
