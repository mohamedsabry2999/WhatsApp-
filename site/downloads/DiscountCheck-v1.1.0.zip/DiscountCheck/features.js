// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "discount",
  "name": "DiscountCheck",
  "nameHtml": "Discount<span>Check</span>",
  "tagline": "الخصم ده مكسب ولا خسارة؟",
  "tools": [
    "discount"
  ],
  "home": "discount",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
