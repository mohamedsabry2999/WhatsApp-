DiscountCheck v1.1.0
الخصم ده مكسب ولا خسارة؟
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (DiscountCheck)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
