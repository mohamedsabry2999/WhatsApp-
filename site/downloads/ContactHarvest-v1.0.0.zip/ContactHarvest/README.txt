ContactHarvest v1.0.0
كل أرقام واتساب اللي اتراسلت معاها في شيت Excel
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (ContactHarvest)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
