ChatLink QR v1.0.0
لينك واتساب برسالة جاهزة + QR لكل حملة
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (ChatLink-QR)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
