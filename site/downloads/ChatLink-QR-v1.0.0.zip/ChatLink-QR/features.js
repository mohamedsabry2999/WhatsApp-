// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "walink",
  "name": "ChatLink QR",
  "nameHtml": "ChatLink <span>QR</span>",
  "tagline": "لينك واتساب برسالة جاهزة + QR لكل حملة",
  "tools": [
    "walink"
  ],
  "home": "walink",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": true,
  "harvest": false,
  "inspect": false
};
