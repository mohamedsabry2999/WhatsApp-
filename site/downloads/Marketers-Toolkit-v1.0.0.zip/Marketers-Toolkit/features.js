// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "toolkit",
  "name": "Marketer's Toolkit",
  "nameHtml": "Marketer's <span>Toolkit</span>",
  "tagline": "كل الأدوات في إضافة واحدة",
  "tools": [
    "replies",
    "crm",
    "walink",
    "post",
    "ads",
    "notion",
    "utm",
    "calc"
  ],
  "home": "replies",
  "popup": "home",
  "welcome": "",
  "replies": true,
  "crm": true,
  "ads": true,
  "notion": true,
  "utm": true,
  "qr": true,
  "harvest": true,
  "inspect": true
};
