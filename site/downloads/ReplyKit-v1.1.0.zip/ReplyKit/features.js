// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "replies",
  "name": "ReplyKit",
  "nameHtml": "Reply<span>Kit</span>",
  "tagline": "ردود جاهزة في واتساب ويب باسم العميل",
  "tools": [
    "replies"
  ],
  "home": "replies",
  "popup": "none",
  "welcome": "replies",
  "siteUrl": "https://tools.mohammedsabry.site",
  "replies": true,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
