PostCheck v1.1.0
راجع الكابشن قبل ما تنشر
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (PostCheck)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
