// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "utm",
  "name": "UTM Studio",
  "nameHtml": "UTM <span>Studio</span>",
  "tagline": "لينكات UTM بنظام تسمية ثابت",
  "tools": [
    "utm"
  ],
  "home": "utm",
  "popup": "none",
  "welcome": "",
  "siteUrl": "https://tools.mohammedsabry.site",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": true,
  "qr": false,
  "harvest": false,
  "inspect": false
};
