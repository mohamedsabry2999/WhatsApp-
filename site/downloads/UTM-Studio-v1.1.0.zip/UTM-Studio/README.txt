UTM Studio v1.1.0
لينكات UTM بنظام تسمية ثابت
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (UTM-Studio)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
