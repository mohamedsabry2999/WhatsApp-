// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "contactharvest",
  "name": "ContactHarvest",
  "nameHtml": "Contact<span>Harvest</span>",
  "tagline": "كل أرقام واتساب اللي اتراسلت معاها في شيت Excel",
  "tools": [],
  "home": "",
  "popup": "harvest",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": true,
  "inspect": false
};
