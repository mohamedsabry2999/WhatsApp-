// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "brief",
  "name": "BriefBuilder",
  "nameHtml": "Brief<span>Builder</span>",
  "tagline": "بريف المحتوى الكامل + برومت التصميم في دقيقة",
  "tools": [
    "brief"
  ],
  "home": "brief",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
