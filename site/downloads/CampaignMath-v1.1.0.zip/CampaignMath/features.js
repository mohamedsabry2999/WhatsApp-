// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "calc",
  "name": "CampaignMath",
  "nameHtml": "Campaign<span>Math</span>",
  "tagline": "كل مؤشرات الحملة + الميزانية من الهدف",
  "tools": [
    "calc"
  ],
  "home": "calc",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
