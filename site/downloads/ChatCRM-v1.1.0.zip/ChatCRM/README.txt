ChatCRM v1.1.0
CRM صغير جوه واتساب ويب
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (ChatCRM)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
