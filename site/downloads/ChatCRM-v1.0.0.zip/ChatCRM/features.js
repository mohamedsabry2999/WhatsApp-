// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "crm",
  "name": "ChatCRM",
  "nameHtml": "Chat<span>CRM</span>",
  "tagline": "CRM صغير جوه واتساب ويب",
  "tools": [
    "crm"
  ],
  "home": "crm",
  "popup": "none",
  "welcome": "",
  "replies": false,
  "crm": true,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
