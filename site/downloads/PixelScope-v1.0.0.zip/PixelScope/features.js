// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "inspect",
  "name": "PixelScope",
  "nameHtml": "Pixel<span>Scope</span>",
  "tagline": "اعرف أي موقع بيستخدم أنهي Pixel وأكواد تتبع",
  "tools": [],
  "home": "",
  "popup": "inspect",
  "welcome": "",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": true
};
