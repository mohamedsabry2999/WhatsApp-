PixelScope v1.0.0
اعرف أي موقع بيستخدم أنهي Pixel وأكواد تتبع
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (PixelScope)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
