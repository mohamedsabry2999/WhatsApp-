// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "notion",
  "name": "IdeaDrop",
  "nameHtml": "Idea<span>Drop</span>",
  "tagline": "احفظ أي فكرة على Notion بضغطة",
  "tools": [
    "notion"
  ],
  "home": "notion",
  "popup": "notion",
  "welcome": "notion",
  "replies": false,
  "crm": false,
  "ads": false,
  "notion": true,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
