Marketer's Toolkit v1.1.0
كل الأدوات في إضافة واحدة
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (Marketers-Toolkit)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
