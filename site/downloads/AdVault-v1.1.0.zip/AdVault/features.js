// متولّد من tools.config.js بواسطة scripts/build.js
var MT_FEATURES = {
  "id": "ads",
  "name": "AdVault",
  "nameHtml": "Ad<span>Vault</span>",
  "tagline": "أرشيف لإعلانات المنافسين من Meta Ad Library",
  "tools": [
    "ads"
  ],
  "home": "ads",
  "popup": "none",
  "welcome": "",
  "siteUrl": "https://tools.mohammedsabry.site",
  "replies": false,
  "crm": false,
  "ads": true,
  "notion": false,
  "utm": false,
  "qr": false,
  "harvest": false,
  "inspect": false
};
