AdVault v1.1.0
أرشيف لإعلانات المنافسين من Meta Ad Library
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (AdVault)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
