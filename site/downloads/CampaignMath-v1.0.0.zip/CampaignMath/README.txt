CampaignMath v1.0.0
كل مؤشرات الحملة + الميزانية من الهدف
تطوير: محمد صبري | Mohamed Sabry

التثبيت:
1) افتح chrome://extensions
2) فعّل Developer mode
3) دوس Load unpacked واختار الفولدر ده (CampaignMath)

الشرح الكامل: https://tools.mohammedsabry.site/install.html
